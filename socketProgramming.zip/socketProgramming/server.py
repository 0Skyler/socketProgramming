import socket

server =  socket.socket()
print("Server socket created")

server.bind(('localhost', 9999))

server.listen(3)
print("Server waiting for connections")

while True:
    client, ipaddress = server.accept()
    name = client.recv(1024).decode()
    print("Server is now connected with", ipaddress, name)
    client.send(bytes("You're now connected with the server", 'utf-8'))
    client.close()
